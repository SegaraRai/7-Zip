// Sha256Prepare.cpp

#include "StdAfx.h"

#include "../../C/Sha256.h"

static struct CSha256Prepare { CSha256Prepare() { Sha256Prepare(); } } g_Sha256Prepare;
