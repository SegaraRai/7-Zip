// DeflateProps.h

#ifndef __DEFLATE_PROPS_H
#define __DEFLATE_PROPS_H

#endif
