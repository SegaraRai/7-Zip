// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include "../Common/Common.h"

#endif
